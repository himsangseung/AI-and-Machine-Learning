Name:Sang-Seung Lee
Hours to complete project: 30
Feedback: 
 Had difficulty looking for edge cases for many Hidden tests.

External Sources (Attributions): 
https://www.geeksforgeeks.org/recursive-insertion-sort/
http://www.cs.bu.edu/~snyder/cs112/CourseMaterials/LinkedListNotes.html
http://fdyhs.fences2016.art/_5_v2E0OWVs/Trying_to_use_an_Insertion_Sort_On_a_Linked_List_and_Failing_Miserably_Code_Tutorial/
https://stackoverflow.com/questions/7685/merge-sort-a-linked-list