Name: SangSeung (Jay) Lee
Hours to complete project: 6
Feedback:
	I wanted to find a better way on defining partition method, 
	than using two external while loops.
	Complexity meets the requirement but hope to know beter way of doing this.

External Sources (Attributions):None

